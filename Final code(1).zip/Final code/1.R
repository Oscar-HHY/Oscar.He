# Model parameters
# Total population size
N <- 100
# Initial infected population
I <- 20
F <- 0
R <- 0
# Transmission rate per susceptible-infected contact
beta <- 0.0000384
# Transmission rate per susceptible-deceased contact
beta_F <- 0.0455
gamma <- 0.0307
# Rate of deceased individuals being removed
sigma <- 0.8 * gamma
# Natural death/birth rate
miu <- 0.0001

# Duration of simulation
days <- 400
# Initial susceptible population
S <- N - I - F - R

# Initializing vectors to store the simulation results
S_vec <- numeric(days)
I_vec <- numeric(days)
F_vec <- numeric(days)
R_vec <- numeric(days)

S_vec[1] <- S
I_vec[1] <- I
F_vec[1] <- F
R_vec[1] <- R

# For gamma_R = gamma * 1
gamma_R <- gamma * 1
gamma_F <- gamma * 0

# Simulation loop
for (day in 2:days) {
  # Calculate new values
  S_new <- S - beta * S * I - beta_F * S * F + miu * N - miu * S
  I_new <- I + beta * S * I + beta_F * S * F - gamma * I - miu * I - gamma_R * I
  F_new <- F + gamma_F * I - sigma * F
  R_new <- R + sigma * F + gamma_R * I
  
  # Update state
  S <- S_new
  I <- I_new
  F <- F_new
  R <- R_new
  
  # Store results
  S_vec[day] <- S
  I_vec[day] <- I
  F_vec[day] <- F
  R_vec[day] <- R
}

# Plotting the results
plot(S_vec, type = "o", col = "blue", ylim = c(0, N), xlab = "Days",
     ylab = "Population", main = "Extension Model, gamma_R = gamma*1")
points(I_vec, type = "o", col = "red")
points(F_vec, type = "o", col = "purple")
points(R_vec, type = "o", col = "orange")
legend("right", legend = c("Susceptible", "Infected", "Funeral", "Removed"),
       col = c("blue", "red", "purple", "orange"), lty = 1, cex = 0.7)
